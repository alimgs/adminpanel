<?php
require_once("../wp-load.php");

$user_ID = get_current_user_id(); 

if ($user_ID == "0") {
    header("Location: https://partiyanshop.com");
    die();
}

if ($user_ID == "2648" || $user_ID == "2651" || $user_ID == "2090" || $user_ID == "2084" || $user_ID == "2094") {
?>

<!doctype html>
<html lang="fa">
<head>
    <title>پنل مدیریت - ادمین</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://partiyanshop.com/wp-content/themes/zanbil/css/fonts/bold/iranyekanwebboldfanum.woff">
    <link rel="icon" href="https://partiyanshop.com/wp-content/uploads/2023/05/partiyan-favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/custom.css?v=<?php echo rand(); ?>">
    <script src="https://asheswp.com/partiyan/asheswp-popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
    <script src="https://asheswp.com/partiyan/jQuery-asheswp.js" type="text/javascript"></script>
</head>
<body>

<section>
    <div class="container" id="adminPanelContainer">
        <!-- Admin panel content will be loaded here -->
    </div>
</section>

<footer>
    <p>کلیه حقوق مادی و معنوی برای این سایت محفوظ می باشد و هرگونه کپی برداری شامل پیگرد قانونی می باشد.</p>
</footer>

<script src="js/jquery.min.js"></script>
<script src="js/popper.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/main.js"></script>
<script type="application/javascript" src="https://asheswp.com/partiyan/jQuery-asheswp.js"></script>
<script src="https://asheswp.com/partiyan/table-sortable-asheswp.js"></script>

<script>
$(document).ready(function(){
    // Load admin panel content via AJAX
    $.ajax({
        url: 'admin_panel.php',
        success: function(response) {
            $('#adminPanelContainer').html(response);
        }
    });
});
</script>

</body>
</html>

<?php
}
?>
