(function($) {

	"use strict";

	$('[data-toggle="tooltip"]').tooltip()

})(jQuery);

$(document).ready(function(){
    
    $('.trackList select').on('change', function() {
        var id = $(this).attr('id');
        var value2 = this.value;
        var codePosti = $("#postCode"+id).val();
        
        if (value2 == "4") {
            
            if (codePosti == "") {
                alert("در صورتی که شماره پیگیری پستی ندارید عدد ۰ را وارد کنید");
                $('#'+id+' option:eq(0)').prop('selected', true)
                return;
            }
            
        }
        
    
        jQuery("#getMsg"+id).html("");
      
        jQuery("#"+id).attr("disabled", "disabled");
      
        jQuery.ajax({
            type: "POST",
            cache: false,
            data: { type: "updateTrack", order_id: id, track_value: value2, codeposti_value: codePosti},
            url: "helper.php",
            dataType: "html",
            success: function (response) {
        
                jQuery("#"+id).attr("disabled", false);
                
                jQuery("#getMsg"+id).html(response);
                
                setTimeout(function(){
                  jQuery("#getMsg"+id).html("");
                }, 2000);
        
                //parse the json data
            },
        });
          
    });
    
    
    
    
    $('.partiyanSendList select').on('change', function() {
        var id = $(this).attr('id');
        var value2 = this.value;
        
    
        jQuery("#getMsgSend"+id).html("");
      
        jQuery("#"+id).attr("disabled", "disabled");
      
        jQuery.ajax({
            type: "POST",
            cache: false,
            data: { type: "updateSendPartiyan", order_id: id, send_value: value2},
            url: "helper.php",
            dataType: "html",
            success: function (response) {
        
                jQuery("#"+id).attr("disabled", false);
                
                jQuery("#getMsgSend"+id).html(response);
                
                setTimeout(function(){
                  jQuery("#getMsgSend"+id).html("");
                }, 2000);
        
                //parse the json data
            },
        });
          
    });
    
    
    
});


