<?php
require_once("../wp-load.php");

$user_ID = get_current_user_id(); 


if ($user_ID == "0") {
    header("Location: https://partiyanshop.com");
    die();
}

if ($user_ID == "2648" || $user_ID == "2984" || $user_ID == "2090" || $user_ID == "2084" || $user_ID == "2094") {

    if ($_POST['type'] == "updateTrack") {
         
         date_default_timezone_set('Asia/Tehran');

         
        $order_id      = (int)$_POST['order_id'];
        $track_value   = (int)$_POST['track_value'];
        
        $order_detail   = wc_get_order( $order_id );
        $billing_phone  = $order_detail->get_billing_phone();


        $track_text = "";
        if ($track_value == "1") {
            $track_text = "در حال پردازش";
        } else if ($track_value == "2") {
            $track_text = "بسته بندی";
        } else if ($track_value == "3") {
            $track_text = "آماده ارسال";
        } else if ($track_value == "4") {
            $track_text = "ارسال شده";
        }

        
        $code_post      = $_POST['codeposti_value'];
        
        $OrderDateTimeMiladi = explode(" " , date('Y-m-d H:i:s'));
        $OrderDateMiladi     = explode("-" , $OrderDateTimeMiladi[0]);
        $OrderDatejalali     = gregorian_to_jalali($OrderDateMiladi[0],$OrderDateMiladi[1],$OrderDateMiladi[2] , '/');
        

        $order_detail       = wc_get_order( $order_id );
        $order_detail_data  = $order_detail->get_items();   
        
        $billing_first_name = $order_detail->get_billing_first_name();
        $billing_last_name = $order_detail->get_billing_last_name();
        

         
        global $wpdb;
         
        $rows = $wpdb->get_results("
                    SELECT * FROM `dtm_track_orders` WHERE order_id = $order_id
                "); 
                
        if (count($rows)) {
            
            $wpdb->update('dtm_track_orders', array('phonenumber' =>$billing_phone, 'code_posti'  => $code_post, 'track_stage'=>$track_value, 'updated_time'=>$OrderDatejalali . ' ' . $OrderDateTimeMiladi[1]), array('order_id'=>$order_id));
            echo "انجام شد";
            
            ini_set("soap.wsdl_cache_enabled","0");
            $sms = new SoapClient("http://api.payamak-panel.com/post/Send.asmx?wsdl",array("encoding"=>"UTF-8"));
            $data = array(
                "username"=>"09916413540",
                "password"=>"94c2gm1",
                "text"=>array($billing_first_name . ' ' . $billing_last_name,$order_id,"\"" . $track_text . "\"","https://partiyanshop.com/track-orders/"),
                "to"=>"$billing_phone",
                "bodyId"=>178841);
            $send_Result = $sms->SendByBaseNumber($data)->SendByBaseNumberResult;


        } else {
            
            $wpdb->insert('dtm_track_orders', array(
                'track_stage' => $track_value,
                'phonenumber' =>$billing_phone, 
                'updated_time'=>$OrderDatejalali . ' ' . $OrderDateTimeMiladi[1],
                'order_id' => $order_id,
                'code_posti'  => $code_post
            ));
            
            ini_set("soap.wsdl_cache_enabled","0");
            $sms = new SoapClient("http://api.payamak-panel.com/post/Send.asmx?wsdl",array("encoding"=>"UTF-8"));
            $data = array(
                "username"=>"09916413540",
                "password"=>"94c2gm1",
                "text"=>array($billing_first_name . ' ' . $billing_last_name,$order_id,"\"" . $track_text . "\"","https://partiyanshop.com/track-orders/"),
                "to"=>"$billing_phone",
                "bodyId"=>178841);
            $send_Result = $sms->SendByBaseNumber($data)->SendByBaseNumberResult;

            
            echo "انجام شد";
            
        }
        
    }
    
    
    if ($_POST['type'] == "updatePrice") {
        $newPrice = $_POST['newPrice'];
        $variationID = $_POST['ID'];
        $hashID = $_POST['hashID'];
        $new_quantity = $_POST['newMaxQty'];
        
        
        if  ($hashID != md5("Dantism".$_POST['ID'])) {
            echo "متاسفانه نتوانسته ایم آپدیت کنیم";
        }else {
            
            update_post_meta($variationID, '_regular_price', $newPrice);
            update_post_meta($variationID, '_price', $newPrice);
            
			
            update_post_meta($variationID, '_stock', $new_quantity);
            
            if ($new_quantity == "0") {
                update_post_meta($variationID, '_is_purchasable', false); // Disable purchasability
                //update_post_meta($variationID, '_stock_status', 'outofstock'); // Set stock status to out of stock
            } else {
                update_post_meta($variationID, '_is_purchasable', false); // Disable purchasability
                update_post_meta($variationID, '_stock_status', 'instock'); // Set stock status to out of stock
            }
			

    
            wc_delete_product_transients($variationID);
            
            //rocket_clean_domain();
    
            echo "آپدیت شد!";
    
            
            
            
        }
        
    }
    
    
    
    
    if ($_POST['type'] == "updateSendPartiyan") {
         
         date_default_timezone_set('Asia/Tehran');

         
        $order_id      = (int)$_POST['order_id'];
        $send_value    = (int)$_POST['send_value'];
        
        
        $OrderDateTimeMiladi = explode(" " , date('Y-m-d H:i:s'));
        $OrderDateMiladi     = explode("-" , $OrderDateTimeMiladi[0]);
        $OrderDatejalali     = gregorian_to_jalali($OrderDateMiladi[0],$OrderDateMiladi[1],$OrderDateMiladi[2] , '/');
        


         
        global $wpdb;
         
        $rows = $wpdb->get_results("
                    SELECT * FROM `dtm_track_send` WHERE order_id = $order_id
                "); 
                
        if (count($rows)) {
            
            $wpdb->update('dtm_track_send', array('send_type' =>$send_value), array('order_id'=>$order_id));
            echo "انجام شد";


        } else {
            
            $wpdb->insert('dtm_track_send', array(
                'order_id' => $order_id,
                'send_type'  => $send_value
            ));
            
            
            echo "انجام شد";
            
        }
        
    }
        
    
    

}

?>